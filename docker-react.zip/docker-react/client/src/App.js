import React, {Component} from 'react';
import './App.css';
const api = process.env.REACT_APP_TO_DO_ITEMS_API;

class App extends Component {
  constructor(props){
    super(props)
    this.state = {
      items: [],
      selectedItem: {},
      newItem: ""
    }
    this.createItem = this.createItem.bind(this);
    this.setInput = this.setInput.bind(this);
  }

  updateItem(id, name, status){
    let requestBody = {
      method: 'PUT',
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        'item_name': name,
        'id': id,
        'complete': !status
      })
    }
    fetch(api + '/items', requestBody)
    .then((data) => {
      this.getItems();
    })
  };


  getItems(){
    fetch(api + '/items')
    .then(res => res.json())
    .then((data)  => {
      this.setState({items: data.reverse()});
      this.forceUpdate();
    })
  };

  createItem(){
    let newItemName = this.state.newItem;
    if(newItemName !== "" || newItemName !== null){
      let requestBody = {
        method: 'POST',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({'item_name': newItemName})
      }
      fetch(api + '/items', requestBody)
      .then((data) => {
        this.getItems();
        this.setState({newItem: ''})
      })
    }
  }

  deleteItem(itemID){
    if(itemID !== "" || itemID !== null){
      let requestBody = {
        method: 'DELETE',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({'id': itemID})
      }
      fetch(api + '/items', requestBody)
      .then((data) => {
        this.getItems();
        this.setState({newItem: ''})
      })
    }
  }

  setInput(input){
    this.setState({newItem: input});
    this.forceUpdate();
  }

  componentDidMount(){
    this.getItems();
  }

  render(){
    var items = this.state.items.map(item => {
      return (<div className='item box-sh'>
        <p>Task: {item.item_name}</p>
        <p>Task ID: {item.id}</p>
        <p>Task Status: {item.complete ? 'Completed' : 'In process'}</p>
        <div className='flt-rght-del'>
          <button className="delete " onClick={() => this.updateItem(item.id, item.item_name, item.complete)}>{item.complete ? 'Restart' : 'Finish'}</button>
          <button className="delete" onClick={() => this.deleteItem(item.id)}>Delete Item</button>
        </div>
        </div>)
    })
    return(
      <div className="row">
        <div className="column">
          <div className='new-item'>
            <p>Create New items</p>
              <label>
                Task Name:
                <input type="text" name="name" value={this.state.newItem} onChange={e => this.setInput(e.target.value)} />
              </label>
              <button className="submit flt-rght"  onClick={this.createItem}> Submit </button>
          </div>
        </div>
        <div className="column">{items}</div>
        <div className="column"> </div>
      </div>
      
    );
  }
}
 

export default App;
