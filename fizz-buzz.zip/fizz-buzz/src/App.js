import React from 'react';

import FizzBuzzInput from './FizzBuzzInput';
import FizzBuzzTimer from './FizzBuzzTimer';
import './App.css';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';

function App() {

  return (
    <Router>
      <div>
        <Switch>
          <Route path="/timer" component={FizzBuzzTimer} />
          <Route path="/" exact component={FizzBuzzInput} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
