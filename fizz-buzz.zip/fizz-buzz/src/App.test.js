import React from 'react';
import App from './App';
import { create } from 'react-test-renderer'


describe('Component testing', function() {
  //Snapshots
  it('App should match snapshot', function() {
    const tree = create(<App />); 
    expect(tree.toJSON()).toMatchSnapshot();
  });
});