import React, { Component } from 'react';
import { Link } from 'react-router-dom';


export default class FizzBuzzInput extends Component {
    constructor(props){
        super(props);
        this.state = {
            fizz: '',
            buzz: '',

        }
    }

    numberValidation(number){
        if(!isNaN(number) && (number <= 10) && (number >= 1)){
            return true
        }
        else{
            return false
        }
    }

    setFizz(e){
        let fizz = e;
        let number = /[^0-9]/;
        if(!number.test(fizz) && e !== ''){
            if(this.numberValidation(fizz)){
                this.setState({fizz: fizz});
            }
        }
        else if(fizz === ''){
            this.setState({fizz: fizz});
        }
    }

    setBuzz(e){
        let buzz = e;
        let number = /[^0-9]/;
        if(!number.test(buzz) && e !== ''){
            if(this.numberValidation(buzz)){
                this.setState({buzz: buzz});
            }
        }
        else if(buzz === ''){
            this.setState({buzz: buzz});
        }
    }

    render(){
        return(
            <div id="fizzBuzzInputForm" className="form-wrapper">
                <p className="page-header fizzbuzz-page-header-margin">Please Enter a fizz and buzz time in seconds. <strong>Values should be 2 to 10, inclusive.</strong></p>
                <p className="fizzbuzz-input-margin"> 
                <span className="fizzbuzz-input-labels">Fizz: </span><input type="text" id="fizzInput" className="fizzbuzz-input" value={this.state.fizz} onChange={e => this.setFizz(e.target.value)}/>
                <span className="fizzbuzz-input-labels">Buzz: </span><input id="buzzInput" className="fizzbuzz-input" value={this.state.buzz} onChange={e => this.setBuzz(e.target.value)}/>
                </p>
                <p className="go-to-button-margin">
                    <Link to={{
                        pathname: '/timer',
                        state: {
                            fizz: this.state.fizz,
                            buzz: this.state.buzz
                        }           
                    }}><button id="goToTimer" className="to-timer" disabled={false}>Go to  Timer &gt;</button>
                    </Link>
                </p>
            </div>
        );
    }
}
