import React from 'react';
import App from './App';
import FizzBuzzInput from './FizzBuzzInput';
import { create } from 'react-test-renderer';
import Enzyme, { shallow, mount} from "enzyme";
import Adapter from "enzyme-adapter-react-16";

Enzyme.configure({ adapter: new Adapter()});


describe('FizzBuzzInput Component testing', function() {
  //Snapshots
  it('FizzBuzzInput component should match snapshot', function() {
    const tree = create(<App><FizzBuzzInput /></App>); 
    expect(tree.toJSON()).toMatchSnapshot();
  });


  it('numberValidation should validate number is in range', () =>{
    const wrapper = mount(<App><FizzBuzzInput /></App>);

    //Should take bottom range
    expect(wrapper.find(FizzBuzzInput).instance().numberValidation("1")).toBe(true);

    //Should take top range
    expect(wrapper.find(FizzBuzzInput).instance().numberValidation("10")).toBe(true);
    
    //Should not take above top range
    expect(wrapper.find(FizzBuzzInput).instance().numberValidation("11")).toBe(false);
    wrapper.unmount();

  });

  it('setFizz can only be set with a number 1-10', () =>{
    const wrapper = mount(<App><FizzBuzzInput /></App>);

    //Should take bottom range
    wrapper.find(FizzBuzzInput).instance().setFizz("1");
    expect(wrapper.find(FizzBuzzInput).state('fizz')).toBe("1");

    //Should take top range
    wrapper.find(FizzBuzzInput).instance().setFizz("10");
    expect(wrapper.find(FizzBuzzInput).state('fizz')).toEqual("10");

    //Should not take 11 and stay the previous value of 10
    wrapper.find(FizzBuzzInput).instance().setFizz("11");
    expect(wrapper.find(FizzBuzzInput).state('fizz')).toBe("10");

    //Should not take non digit characters and stay the previous value of 10
    wrapper.find(FizzBuzzInput).instance().setFizz("x");
    expect(wrapper.find(FizzBuzzInput).state('fizz')).toBe("10");

    //Should take an empty string
    wrapper.find(FizzBuzzInput).instance().setFizz('');
    expect(wrapper.find(FizzBuzzInput).state('fizz')).toBe('');

    wrapper.unmount();
  });


  it('setBuzz can only be set with a number 1-10', () =>{
    const wrapper = mount(<App><FizzBuzzInput /></App>);

    //Should take bottom range
    wrapper.find(FizzBuzzInput).instance().setBuzz("1");
    expect(wrapper.find(FizzBuzzInput).state('buzz')).toBe("1");

    //Should take top range
    wrapper.find(FizzBuzzInput).instance().setBuzz("10");
    expect(wrapper.find(FizzBuzzInput).state('buzz')).toEqual("10");
    
    //Should not take 11 and stay the previous value of 10
    wrapper.find(FizzBuzzInput).instance().setBuzz("11");
    expect(wrapper.find(FizzBuzzInput).state('buzz')).toBe("10");

    //Should not take non digit characters and stay the previous value of 10
    wrapper.find(FizzBuzzInput).instance().setBuzz("x");
    expect(wrapper.find(FizzBuzzInput).state('buzz')).toBe("10");
    
    //Should take an empty string
    wrapper.find(FizzBuzzInput).instance().setBuzz('');
    expect(wrapper.find(FizzBuzzInput).state('buzz')).toBe('');
    
    wrapper.unmount();
  });

});