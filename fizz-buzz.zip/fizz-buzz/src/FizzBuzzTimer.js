import React from 'react';
import { Link } from 'react-router-dom';
import moment from 'moment';


export default class FizzBuzzTimer extends React.Component {
    

    constructor(props){
        super(props);
        this.state = {
            fizz: '',
            buzz: '',
            running: false,
            elapsed: 0,
            displayTime: '0:00:00',
            backDisabled: false,
            fizzText: '',
            buzzText: ''
        }
    }
    
    componentDidMount(){
        if(!this.props.location){
            this.setState(
                {
                    fizz: '2',
                    buzz: '3',
                    running: false,
                    elapsed: 0,
                    displayTime: '0:00:00',
                    backDisabled: false,
                    fizzText: '',
                    buzzText: ''
                }
            );
        }
        else{
            this.setState({
                fizz: this.props.location.state ? this.props.location.state.fizz : '' ,
                buzz: this.props.location.state ? this.props.location.state.buzz : ''
            });
        }
    }

    getState(){
        return this.state;
    }

    startTimer = () =>{
        if(this.state.running === false){
            this.setState({running: true});
            this.timer = setInterval(() => this.incrementTimer(), 1000);
            this.setState({backDisabled: true});
        }
    }

    stopResetTimer = () =>{
        if(this.state.running === true){
            this.setState({running: false});
            clearInterval(this.timer);
        }
        if(this.state.running === false){
            this.setState({
                elapsed: 0,
                displayTime: '0:00:00'
            });
            this.setState({backDisabled: false});
        }
    }

    incrementTimer(){
        this.setState({elapsed: this.state.elapsed + 1});
        this.setDisplayTime();
        this.setFizzBuzzText();
    }
    

    setDisplayTime(){
        this.setState({displayTime: moment().hour(0).minute(0).second(this.state.elapsed).format('H:mm:ss')});
    }


    setFizzBuzzText(){
        if(this.state.elapsed % this.state.fizz === 0 ){
            this.setState({fizzText: 'fizz'});
        }
        else{
            this.setState({fizzText: ''});
        }
        this.state.elapsed % this.state.fizz === 0 ? this.setState({fizzText: 'fizz'}): this.setState({fizzText: ''});
        this.state.elapsed % this.state.buzz === 0 ? this.setState({buzzText: 'buzz'}): this.setState({buzzText: ''});
    }


    render(){
        return(
            <div>
                <div id="fizzBuzzInputForm" className="form-wrapper">
                    <div className="set-times-position">
                        <Link to="/">
                            <button disabled={this.state.backDisabled} id="setTimes"  className="to-timer">&lt; Set Times</button>
                        </Link>
                    </div>
                
                    <p className="page-header fizzbuzz-input-margin">Time Elapsed</p>
    
                    <div id="timeElapsed fizzbuzz-input-margin" className="time-elapsed">{this.state.displayTime}</div>
    
                    <p className="go-to-button-padding">
                        <button id="startTimer" className="time-control-button time-start" onClick={this.startTimer}>Start</button>
                        <button id="endTimer" className="time-control-button time-stop" onClick={this.stopResetTimer}>Stop / Reset</button>
                    </p>
                    <p className="fizz-text">{this.state.fizzText}{this.state.buzzText} &nbsp;</p>
                </div>
            </div>
        );
    }

    
}

