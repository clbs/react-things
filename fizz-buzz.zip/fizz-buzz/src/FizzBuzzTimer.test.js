import React from 'react';
import FizzBuzzTimer from './FizzBuzzTimer';
import { create } from 'react-test-renderer';
import Enzyme, { mount} from "enzyme";
import Adapter from "enzyme-adapter-react-16";
import { MemoryRouter } from 'react-router';

Enzyme.configure({ adapter: new Adapter()});

const states = {
  location:{
    state:{
      fizz: 1,
      buzz: 1
    }
  }
}

describe('FizzBuzzTimer Component testing', function() {
  //Snapshot
  it('FizzBuzzTimer component should match snapshot', function() {
    const states = {
      fizz: 1,
      buzz: 2
    }
    const tree = create(<MemoryRouter initialEntries={[{pathName: "/timer", state:{fizz: 4, buzz: 2}}]}><FizzBuzzTimer /></MemoryRouter>); 
    expect(tree.toJSON()).toMatchSnapshot();
  });

  
  it('Timer should start and run', () =>{
    const wrapper = mount(<MemoryRouter 
      initialEntries={[{pathName: "/timer"}]} 
      initalIndex={0}>
        <FizzBuzzTimer />
      </MemoryRouter>);

    //State running should be set to true when timer is running
    wrapper.find('.time-start').simulate('click');
    expect(wrapper.find(FizzBuzzTimer).state('running')).toBe(true);

    wrapper.unmount();
  });

  it('Timer should stop after being started', () =>{
    const wrapper = mount(<MemoryRouter 
      initialEntries={[{pathName: "/timer"}]} 
      initalIndex={0}>
        <FizzBuzzTimer />
      </MemoryRouter>);

    //State running should be set to true when timer is running
    wrapper.find('.time-start').simulate('click');
    expect(wrapper.find(FizzBuzzTimer).state('running')).toBe(true);
  
    //Clicking stop should set timer running to false
    wrapper.find('.time-stop').simulate('click');
    expect(wrapper.find(FizzBuzzTimer).state('running')).toBe(false); 

    //Clicking stop again should reset timer
    //Run up 30 seconds
    let attempts = 30;
    while(0 < attempts){
      wrapper.find(FizzBuzzTimer).instance().incrementTimer();
      attempts --;
    }
    wrapper.instance().forceUpdate();
    //Check for success
    expect(wrapper.find('.time-elapsed').text()).toBe('0:00:30');
    //Click again to reset timer
    wrapper.find('.time-stop').simulate('click');
    //Make sure running is still false
    expect(wrapper.find(FizzBuzzTimer).state('running')).toBe(false);
    //Make sure time reset 
    expect(wrapper.find('.time-elapsed').text()).toBe('0:00:00'); 

    wrapper.unmount();
  });

  it('Fizz Buzz should display at selected intervals', () =>{
    const wrapper = mount(<MemoryRouter 
      initialEntries={[{pathName: "/timer"}]} 
      initalIndex={0}>
        <FizzBuzzTimer {...states}/>
      </MemoryRouter>);

    //Clicking stop again should reset timer
    //Run up 30 seconds
    wrapper.find(FizzBuzzTimer).setState({fizz: 2, buzz: 3});
    let attempts = 30;
    while(0 < attempts){
      wrapper.find(FizzBuzzTimer).instance().incrementTimer();
      attempts --;
    }
    //Check for success
    expect(wrapper.find('.time-elapsed').text()).toBe('0:00:30');
    //Fizz and buzz should be displayed there should be no remainder after the modulus operator
    expect(wrapper.find(FizzBuzzTimer).instance().getState().fizzText).toBe('fizz');
    expect(wrapper.find(FizzBuzzTimer).instance().getState().buzzText).toBe('buzz');    

    //Run up two more counts and check that buzz text dissappears
    attempts = 2;
    while(0 < attempts){
      wrapper.find(FizzBuzzTimer).instance().incrementTimer();
      attempts --;
    }
    //Check for success
    expect(wrapper.find('.time-elapsed').text()).toBe('0:00:32');
    //Only fizz should be displayed
    expect(wrapper.find(FizzBuzzTimer).instance().getState().fizzText).toBe('fizz');
    expect(wrapper.find(FizzBuzzTimer).instance().getState().buzzText).toBe('');  

    //Run up one more counts and check that fizz text dissappears
    attempts = 1;
    while(0 < attempts){
      wrapper.find(FizzBuzzTimer).instance().incrementTimer();
      attempts --;
    }
    //Check for success
    expect(wrapper.find('.time-elapsed').text()).toBe('0:00:33');
    //Fizz and buzz should be displayed there should be no remainder after the modulus operator
    expect(wrapper.find(FizzBuzzTimer).instance().getState().fizzText).toBe('');
    expect(wrapper.find(FizzBuzzTimer).instance().getState().buzzText).toBe('buzz');  

    wrapper.unmount();
  }); 
});